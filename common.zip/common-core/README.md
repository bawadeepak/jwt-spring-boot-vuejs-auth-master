# Name: Common Core

# Description
* Spring-boot application to share common code.

# Contents
* Base model classes
* HDFS Config linked with 'hdfs' profile
* Kafka Config linked with 'kafka' profile
* Security Config to protect all APIs, verify JWT and extract claims for use by API
* Swagger Config to provide UI for testing exposed APIs
* Healthcheck Controller with GET mapping - /healthcheck
* Util classes - DateUtil, UserUtil