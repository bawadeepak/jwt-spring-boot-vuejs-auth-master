package au.gov.acic.dp.common.data.converter.mapper.impl;

import au.gov.acic.dp.common.data.converter.input.InputSource;
import au.gov.acic.dp.common.data.converter.mapper.Mapper;
import au.gov.acic.dp.common.data.converter.output.OutputFormat;

public abstract class MapperImpl<I, O> implements Mapper<InputSource<I>, O> {

	@Override
	public O convert(InputSource<I> inputSource) {
		OutputFormat<O> output = performConversion(inputSource.retrieveData());
		return output.retrieveData();
	}

	abstract OutputFormat<O> performConversion(I input);

}
