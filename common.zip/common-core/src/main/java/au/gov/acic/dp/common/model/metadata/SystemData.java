package au.gov.acic.dp.common.model.metadata;

import java.time.LocalDate;

import javax.validation.constraints.Email;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemData {

	private String id;
	private String stagedPath;
	private String hbaseTableName;
	private String hbaseFamilyName;
	private String hbaseRowKey;
	private String hbaseColumnQualifier;
	private String hdfsPath;
	private String originalDataFilename;
	private String uploadUsername;
	@Email
	private String uploadUserEmail;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern ="yyyy-MM-dd")
	private LocalDate uploadDate;
	private SecurityTag securityTag;

}
