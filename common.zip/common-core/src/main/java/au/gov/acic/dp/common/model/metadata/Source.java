package au.gov.acic.dp.common.model.metadata;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Data
public class Source {

	public enum OrganisationName {
		VICPOL, NSWPF, QPS, ACIC, AFP, HA
	}

	public enum SystemName {
		LEAP, COPS, FDH, NPRS, ACID, QPRIME, @JsonProperty("PROMIS-AFP") PROMIS, NCTL, NGL, DGMS, RAWSON
	}

	private OrganisationName organisationName;
	private SystemName systemName;
	@Length(min=1, max=255, message="{datasetName.length}")
	private String datasetName;

}
