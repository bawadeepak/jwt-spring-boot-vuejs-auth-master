package au.gov.acic.dp.common.controller.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@NoArgsConstructor
@Data
public class ApiResponse {

	private HttpStatus status;
	private String message;

	public ApiResponse(final HttpStatus status, final String message) {
		this.status = status;
		this.message = message;
	}
}

