package au.gov.acic.dp.common.repository.hbase;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import au.gov.acic.dp.common.repository.hbase.model.HbaseColumn;
import au.gov.acic.dp.common.repository.hbase.model.HbaseRecord;

@Profile("hdfs")
@Repository
public class HbaseRepositoryImpl implements HbaseRepository {

	private final Logger logger = LoggerFactory.getLogger(HbaseRepositoryImpl.class);

	@Override
	public void saveRecord(final HbaseRecord record) {
		logger.debug("NOT YET IMPLEMENTED");
	}

	@Override
	public HbaseRecord getRecord(final String tableName, final String familyName, final String rowKey, final List<String> columnQualifiers) {
		logger.debug("NOT YET IMPLEMENTED, returning mock data!");
		final HbaseRecord r = new HbaseRecord("Table", "family", Collections.singletonMap(rowKey, new HbaseColumn(columnQualifiers.get(0), "Test Data 1, Test Data 1, Test Data 1".getBytes())));
		return r;
	}

	@Override
	public byte[] getCellValue(final String tableName, final String familyName, final String rowKey, final String columnQualifier) {
		final HbaseRecord record = getRecord(tableName, familyName, rowKey, Collections.singletonList(columnQualifier));
		return record.getColumns().get(rowKey).getValue();
	}

}
