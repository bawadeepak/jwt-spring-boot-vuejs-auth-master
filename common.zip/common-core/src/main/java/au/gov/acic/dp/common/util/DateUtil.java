package au.gov.acic.dp.common.util;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Locale;

import org.springframework.util.StringUtils;

public final class DateUtil {

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

	public static SimpleDateFormat getDateFormat(final String pattern) {
		if(StringUtils.isEmpty(pattern)) {
			return new SimpleDateFormat(DEFAULT_DATE_FORMAT, Locale.getDefault());
		}
		return new SimpleDateFormat(pattern, Locale.getDefault());
	}

	public static SimpleDateFormat getDefaultDateFormat() {
		return getDateFormat(null);
	}

	public static boolean isDateFuture(final LocalDate date) {
		return date.isAfter(LocalDate.now());
	}

	public static boolean isDate50YrsOld(final LocalDate date) {
		boolean old = false;
		final LocalDate fiftyYrsAgo = LocalDate.now().minusYears(50);
		if (date.isBefore(fiftyYrsAgo)) {
			old = true;
		}
		return old;
	}

}
