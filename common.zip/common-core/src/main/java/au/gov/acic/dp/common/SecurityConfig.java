package au.gov.acic.dp.common;

import java.io.IOException;
import java.io.InputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;

import au.gov.acic.dp.common.security.JwtAuthenticationFilter;
import au.gov.acic.dp.common.security.JwtUtil;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	public static final String RESOURCE_NAME_CERTIFICATE = "nism001s.crt";
	public static final String RESOURCE_NAME_JWKS = "jwks.json";

	public static final String HEADER_JWT = "X-JWT-Assertion";
	public static final String USER_CLAIM_USER_ID = "userid";
	public static final String USER_CLAIM_GIVEN_NAME = "given_name";
	public static final String USER_CLAIM_FAMILY_NAME = "family_name";
	public static final String USER_CLAIM_EMAIL = "email";
	public static final String USER_CLAIM_GROUPS = "groups";

	@Autowired
	private JwtUtil jwtUtil;

	@Override
	protected void configure(final HttpSecurity http) throws Exception {

		http.authorizeRequests()
		.antMatchers("/healthcheck", "/swagger-ui.html","/swagger-resources/**", "/v2/**", "/webjars/**")
		.permitAll()
		.anyRequest()
		.authenticated().and()
		.addFilterBefore(new JwtAuthenticationFilter(jwtUtil), UsernamePasswordAuthenticationFilter.class);

		http.cors().and().csrf().disable().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
	}

	@Bean
	public JWSVerifier getJwsVerifier() throws CertificateException, IOException {
		final InputStream file = new ClassPathResource(RESOURCE_NAME_CERTIFICATE).getInputStream();
		final CertificateFactory cf = CertificateFactory.getInstance("X.509");
		final Certificate certificate = cf.generateCertificate(file);
		return new RSASSAVerifier((RSAPublicKey)certificate.getPublicKey());
	}

	@Bean
	public ConfigurableJWTProcessor<SecurityContext> jwtProcessor() throws IOException, ParseException {
		final ConfigurableJWTProcessor<SecurityContext> jwtProcessor = new DefaultJWTProcessor<>();
		final InputStream file = new ClassPathResource(RESOURCE_NAME_JWKS).getInputStream();
		final JWKSet jwkSet = JWKSet.load(file);
		final JWKSource<SecurityContext> keySource = new ImmutableJWKSet<>(jwkSet);
		jwtProcessor.setJWSKeySelector(new JWSVerificationKeySelector<>(JWSAlgorithm.RS256, keySource));
		return jwtProcessor;
	}
}
