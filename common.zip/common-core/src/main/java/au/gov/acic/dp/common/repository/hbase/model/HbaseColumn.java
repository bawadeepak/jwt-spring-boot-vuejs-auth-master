package au.gov.acic.dp.common.repository.hbase.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HbaseColumn {

	public String columnQualifier;
	public byte[] value;

}
