package au.gov.acic.dp.common.data.converter.repository.cache;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import au.gov.acic.dp.common.data.converter.repository.cache.model.JsonMappingDetails;

@Repository
public class PropertiesRepository implements MappingRepository<Map<String, JsonMappingDetails>> {

	public static final String DISPLAY_NAME = "displayName";
	public static final String JSON_DEPTH = "jsonDepth";
	public static final String CONVERTER = "displayName";
	public static final String JSON_FIELD_NAME = "jsonFieldName";
	public static final String MUTLIPLE = "multiple";
	public static final String OBJECT_TREE = "object";

	@Override
	@Cacheable("propertiesMapping")
	public Map<String, JsonMappingDetails> getMappingInformation() {
		return getJSONObjectMapping();
	}
	
	private static Map<String, JsonMappingDetails> getJSONObjectMapping() {
		Map<String, JsonMappingDetails> jsonMappingsMap = new LinkedHashMap<String, JsonMappingDetails>();
		Map<String, String> mappings = getJSONObjectMappingData();
		mappings.forEach((parameterKey, parameterValue) -> {
			StringTokenizer tokens = new StringTokenizer(parameterKey, ".");
			String hbaseKey = tokens.nextToken();
			String property = tokens.nextToken();
			JsonMappingDetails jsonMappingDetails = null;
			if (!jsonMappingsMap.containsKey(hbaseKey)) {
				jsonMappingDetails = new JsonMappingDetails();
				jsonMappingsMap.put(hbaseKey, jsonMappingDetails);
			} else {
				jsonMappingDetails = jsonMappingsMap.get(hbaseKey);
			}
			storeMappingDetails(jsonMappingDetails, property, parameterValue);
	    });
		return jsonMappingsMap;
	}
	
	private static void storeMappingDetails(JsonMappingDetails jsonMappingDetails, String property,
			String parameterValue) {
		if (property.equalsIgnoreCase(DISPLAY_NAME)) {
			jsonMappingDetails.setDisplayName(parameterValue);
		} else if (property.equalsIgnoreCase(JSON_DEPTH)) {
			jsonMappingDetails.setJsonDepth(parameterValue);
		} else if (property.equalsIgnoreCase(CONVERTER)) {
			jsonMappingDetails.setConverter(parameterValue);
		} else if (property.equalsIgnoreCase(JSON_FIELD_NAME)) {
			jsonMappingDetails.setJsonFieldName(parameterValue);
		} else if (property.equalsIgnoreCase(MUTLIPLE)) {
			jsonMappingDetails.setMultipleValues(parameterValue.equalsIgnoreCase("true")? true : false);
		} else if (property.equalsIgnoreCase(OBJECT_TREE)) {
			jsonMappingDetails.setObjectTree(parameterValue.equalsIgnoreCase("true")? true : false);
		} 
	}

	private static Map<String, String> getJSONObjectMappingData() {
		Map<String, String> mappingData = new LinkedHashMap<String, String>();
		mappingData.put("P~alias.displayName", "Aliases");
		mappingData.put("P~alias.converter", "SentenceCase");
		mappingData.put("P~alias.jsonDepth", "person.alias");
		mappingData.put("P~alias.jsonFieldName", "NameType");
		mappingData.put("P~alias.multiple", "true");
		
		mappingData.put("P~alias~nameType.displayName", "Type of Name");
		mappingData.put("P~alias~nameType.converter", "SentenceCase");
		mappingData.put("P~alias~nameType.jsonDepth", "person.alias.nameType");
		mappingData.put("P~alias~nameType.jsonFieldName", "NameType");
		mappingData.put("P~alias~nameType.multiple", "false");
		
		mappingData.put("P~alias~givenName.displayName", "Given Name");
		mappingData.put("P~alias~givenName.converter", "SentenceCase");
		mappingData.put("P~alias~givenName.jsonDepth", "person.alias.givenName");
		mappingData.put("P~alias~givenName.jsonFieldName", "GivenNameType");
		mappingData.put("P~alias~givenName.multiple", "true");
		
		mappingData.put("P~physicalDescription~height.displayName", "Type of Name");
		mappingData.put("P~physicalDescription~height.converter", "SentenceCase");
		mappingData.put("P~physicalDescription~height.jsonDepth", "person.physicalDescription.height");
		mappingData.put("P~physicalDescription~height.jsonFieldName", "NameType");
		mappingData.put("P~physicalDescription~height.multiple", "false");

		mappingData.put("O~file.displayName", "Aliases");
		mappingData.put("O~file.converter", "SentenceCase");
		mappingData.put("O~file.jsonDepth", "object.file");
		mappingData.put("O~file.jsonFieldName", "NameType");
		mappingData.put("O~file.multiple", "true");
		
		mappingData.put("O~file~id.displayName", "Given Name");
		mappingData.put("O~file~id.converter", "SentenceCase");
		mappingData.put("O~file~id.jsonDepth", "object.file.id");
		mappingData.put("O~file~id.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~id.multiple", "false");
		
		mappingData.put("O~file~type.displayName", "Given Name");
		mappingData.put("O~file~type.converter", "SentenceCase");
		mappingData.put("O~file~type.jsonDepth", "object.file.type");
		mappingData.put("O~file~type.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~type.multiple", "false");
		
		mappingData.put("O~file~content.displayName", "Given Name");
		mappingData.put("O~file~content.converter", "SentenceCase");
		mappingData.put("O~file~content.jsonDepth", "object.file.content");
		mappingData.put("O~file~content.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~content.multiple", "false");
		
		return mappingData;
	}
	
}