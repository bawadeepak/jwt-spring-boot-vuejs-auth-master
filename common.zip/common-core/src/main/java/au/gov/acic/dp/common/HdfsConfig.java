package au.gov.acic.dp.common;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


@Configuration
@Profile("hdfs")
public class HdfsConfig {

	@Value("${hdfs.uri}")
	private String hdfsUri;

	@Value("${hdfs.username}")
	private String hdfsUsername;

	@Bean
	public FileSystem getHadoopFileSystem() throws IOException, InterruptedException {
		return FileSystem.get(URI.create(hdfsUri), getHadoopConfiguration(), hdfsUsername);
	}

	@Bean
	public org.apache.hadoop.conf.Configuration getHadoopConfiguration() {
		final org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
		conf.set(FileSystem.FS_DEFAULT_NAME_KEY, hdfsUri);
		conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
		conf.set("fs.file.impl", org.apache.hadoop.fs.LocalFileSystem.class.getName());
		return conf;
	}
}
