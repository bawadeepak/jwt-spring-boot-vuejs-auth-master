package au.gov.acic.dp.common.data.converter.mapper;

import org.springframework.util.MimeType;

import lombok.Data;

@Data
public class Format {

	private String name;
	private String version;
	private MimeType mimeType;
	
}
