package au.gov.acic.dp.common.data.converter.input.impl;

import java.util.Map;
import java.util.TreeMap;

import au.gov.acic.dp.common.data.converter.input.InputSource;

public class InputSourceHBase implements InputSource<Map<String, String>> {

	@Override
	public Map<String, String> retrieveData() {
		return getDummyHBasePersonResponse();
	}

	private static Map<String, String> getDummyHBasePersonResponse() {
		Map<String, String> valueMap = new TreeMap<String, String>();
		valueMap.put("P~alias~id~0", "1");
		valueMap.put("P~alias~fullName~0", "Apple Banana Fruit");
		valueMap.put("P~alias~nameType~0", "PREFERRED NAME");
		valueMap.put("P~alias~givenName~0~0", "Deepak");
		valueMap.put("P~alias~givenName~0~1", "Dipak");
		valueMap.put("P~alias~id~1", "1");
		valueMap.put("P~alias~fullName~1", "Apple Banana Fruit");
		valueMap.put("P~alias~nameType~1", "OTHER NAME");
		valueMap.put("P~alias~givenName~1~0", "Deepak1");
		valueMap.put("P~alias~givenName~1~1", "Deepak2");
		valueMap.put("P~alias~givenName~1~2", "Deepak3");
//		valueMap.put("P~alias~DB~source~1", "Name Type DB Source - DummyHBase");
//		valueMap.put("P~alias~DB~type~1", "Name Type DB Source type - HBase");
		valueMap.put("P~alias~id~2", "2");
		valueMap.put("P~alias~fullName~2", "Apple Banana Fruit");
		valueMap.put("P~alias~nameType~2", "OTHER NAME");
		valueMap.put("P~alias~givenName~2~0", "Bawa1");
		valueMap.put("P~alias~givenName~2~1", "Bawa2");
		valueMap.put("P~alias~givenName~2~2", "Bawa3");
		valueMap.put("P~physicalDescription~id~0", "6");
		valueMap.put("P~physicalDescription~height~0", "183");
		valueMap.put("P~physicalDescription~weight~0", "80");
		valueMap.put("P~physicalDescription~buildCode~0", "thin");
//		valueMap.put("P~physicalDescription~height~1", "183");
		valueMap.put("O~file~id~0", "1");
		valueMap.put("O~file~type~0", "fullImage");
		valueMap.put("O~file~content~0", "BLOB");
		valueMap.put("O~file~id~1", "2");
		valueMap.put("O~file~type~1", "thumbImage");
		valueMap.put("O~file~content~1", "CLOB");
		valueMap.put("O~identification~id~0", "3");
		valueMap.put("O~identification~issuingAuthority~0", "WA");
		valueMap.put("O~identification~value~0", "3066319");
		valueMap.put("L~loc~id~0", "1");
		valueMap.put("L~loc~type~0", "POSTAL");
		valueMap.put("L~loc~unstructured~0", "PO BOX 797 SUBIACO 6008");
		valueMap.put("L~loc~id~1", "2");
		valueMap.put("L~loc~type~1", "PERMANENT");
		valueMap.put("L~loc~unstructured~1", "HOME ADDRESS");
		valueMap.put("E~involvement~id~0", "1");
		valueMap.put("E~involvement~type~0", "bail");
		valueMap.put("E~involvement~id~1", "2");
		valueMap.put("E~involvement~type~1", "warrant");
		valueMap.putAll(getDummyHBaseCallData());
		return valueMap;
	}

	private static Map<String, String> getDummyHBaseCallData() {
		Map<String, String> valueMap = new TreeMap<String, String>();
		valueMap.put("E~links~id~0", "0");
		valueMap.put("E~links~aPartyNumber~0", "61418387008");
		valueMap.put("E~links~localRefId~0", "987654623");
		valueMap.put("E~links~bPartyNumber~0", "61408894780");
		valueMap.put("E~links~calls~id~0", "01");
		valueMap.put("E~links~calls~CallDate~0", "1533564000000");
		valueMap.put("E~links~calls~investigation~0", "Pheniox");
		valueMap.put("E~links~calls~id~1", "01");
		valueMap.put("E~links~calls~CallDate~1", "1533564000001");
		valueMap.put("E~links~calls~investigation~1", "Pheniox1");
		valueMap.put("E~links~calls~id~2", "01");
		valueMap.put("E~links~calls~CallDate~2", "1533564000002");
		valueMap.put("E~links~calls~investigation~2", "Pheniox2");

//		valueMap.put("E~links~id~1", "0");
//		valueMap.put("E~links~aPartyNumber~1", "61418387001");
//		valueMap.put("E~links~localRefId~1", "1111111111111");
//		valueMap.put("E~links~bPartyNumber~1", "61408894781");
		return valueMap;
	}

}
