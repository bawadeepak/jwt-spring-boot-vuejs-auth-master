package au.gov.acic.dp.common.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper=false)
public class ErrorResponse extends ApiResponse {

	private List<String> errors;
	private Map<String, List<String>> fieldErrors;

	public ErrorResponse(final HttpStatus status, final String message) {
		super(status, message);
	}

	public ErrorResponse setErrors(final List<String> errors) {
		this.errors = errors;
		return this;
	}

	public ErrorResponse setFieldErrors(final Map<String, List<String>> fieldErrors) {
		this.fieldErrors = fieldErrors;
		return this;
	}
}

