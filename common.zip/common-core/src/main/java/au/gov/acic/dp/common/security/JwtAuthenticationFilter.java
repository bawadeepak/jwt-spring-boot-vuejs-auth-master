package au.gov.acic.dp.common.security;

import au.gov.acic.dp.common.SecurityConfig;
import au.gov.acic.dp.common.security.model.DataPipelineUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Collections;

public class JwtAuthenticationFilter extends GenericFilterBean {

	private final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

	private final JwtUtil jwtUtil;

	public JwtAuthenticationFilter(final JwtUtil jwtUtil) {
		super();
		this.jwtUtil = jwtUtil;
	}

	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
			throws IOException, ServletException {
		final Authentication authentication = getAuthentication((HttpServletRequest) request);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		chain.doFilter(request, response);
		resetAuthenticationAfterRequest();
	}

	private Authentication getAuthentication(final HttpServletRequest request) {
		final String token = request.getHeader(SecurityConfig.HEADER_JWT);
		logger.debug("{}: {}", SecurityConfig.HEADER_JWT, token);
		if (!StringUtils.isEmpty(token)) {
			final DataPipelineUser user = jwtUtil.validateAndDecodeToken(token);
			logger.debug("DP user: {}", user);
			return user != null ? new UsernamePasswordAuthenticationToken(user, null, Collections.emptyList()) : null;
		}
		return null;
	}

	private void resetAuthenticationAfterRequest() {
		SecurityContextHolder.getContext().setAuthentication(null);
	}

}
