package au.gov.acic.dp.common.data.converter.output.impl;

import org.json.simple.JSONObject;

import au.gov.acic.dp.common.data.converter.output.OutputFormat;

public class OutputFormatJson implements OutputFormat<JSONObject> {

	private JSONObject jsonObject;
	
	public void setOutput(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}
	
	@Override
	public JSONObject retrieveData() {
		return jsonObject;
	}

}
