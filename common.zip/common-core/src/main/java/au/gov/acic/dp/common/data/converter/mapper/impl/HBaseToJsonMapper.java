package au.gov.acic.dp.common.data.converter.mapper.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.gov.acic.dp.common.data.converter.output.OutputFormat;
import au.gov.acic.dp.common.data.converter.output.impl.OutputFormatJson;
import au.gov.acic.dp.common.data.converter.repository.cache.PropertiesRepository;
import au.gov.acic.dp.common.data.converter.repository.cache.model.JsonMappingDetails;

@Component
public class HBaseToJsonMapper extends MapperImpl<Map<String, String>, JSONObject> {

	private static final Logger logger = LoggerFactory.getLogger(HBaseToJsonMapper.class);

	@Autowired
	private PropertiesRepository propertiesRepository;

	@Override
	public OutputFormat<JSONObject> performConversion(Map<String, String> input) {
		OutputFormatJson json = new OutputFormatJson();
		json.setOutput(new JSONObject());
		Map<String, JSONObject> existingJSONObjects = new HashMap<String, JSONObject>();
		Map<String, JSONArray> existingJSONArrays = new HashMap<String, JSONArray>();
		propertiesRepository.getMappingInformation().forEach((key, jsonMappingInfo)  -> {
			populateJSON(json.retrieveData(), input, existingJSONObjects, jsonMappingInfo, propertiesRepository.getMappingInformation(), existingJSONArrays);
		});
		if (logger.isDebugEnabled()) logger.debug(json.retrieveData().toJSONString());
		return json;
	}

	private static void populateJSON(JSONObject parentObject, Map<String, String> hbaseData, Map<String, JSONObject> existingJSONObjects, 
			JsonMappingDetails jsonMappingInfo, Map<String, JsonMappingDetails> jsonMappings, Map<String, JSONArray> existingJSONArrays) {
		String[] splits = jsonMappingInfo.getJsonDepth().split("[, ?.@]+"); // Split Json Depth to get various json object to be created.
		String[] keySplits = jsonMappingInfo.getDataSourceKey().split("~"); // Split Data Key to get key portions. This is used to retrieve the JSON Mapping relevant for particular key.
		String keyRepeatId = keySplits[0];
		for (int i=0; i<(keySplits.length - 1); i++) {
			if (i > 0) {
				keyRepeatId = keyRepeatId + "~" + keySplits[i];
			}
		}
//		int noOfRepeats = getNoOfRepeatsFromData(keySplits[0] + "~" + keySplits[1], "~id", hbaseData); // Get number of unique id items for this type of key based on its id column.
		int noOfRepeats = getNoOfRepeatsFromData(keyRepeatId, "~id", hbaseData); // Get number of unique id items for this type of key based on its id column.
		for (int repeatPosition=0; repeatPosition < noOfRepeats; repeatPosition++) { // Repeat for each type of data set.
			if (!hbaseData.containsKey(jsonMappingInfo.getDataSourceKey() + "~" + repeatPosition) && !jsonMappingInfo.isMultipleValues()) {
				continue; // If current key does not have any data then break from loop.
			}
			processCurrentPosition(parentObject, hbaseData, existingJSONObjects, jsonMappingInfo.getDataSourceKey(), jsonMappingInfo, jsonMappings, existingJSONArrays, splits, repeatPosition);
		}
	}

	private static void processCurrentPosition(JSONObject parentObject, Map<String, String> hbaseData, Map<String, JSONObject> existingJSONObjects, 
			String hbaseDataKey, JsonMappingDetails jsonMappingInfo, Map<String, JsonMappingDetails> jsonMappings, Map<String, JSONArray> existingJSONArrays, 
			String[] splits, int repeatPosition) {
		JSONObject prevJsonObj = parentObject;
		StringBuilder jsonObjKey = new StringBuilder("");
		for (int splitPosition=0; splitPosition < splits.length; splitPosition++) { // loop thru JSON Depth splits and create required JSON objects.
			// Do not store values for first two splits as the first item belongs to POLE type and second is first level data type?
			if (splitPosition == (splits.length - 1) && splits.length > 2) { 
				storeJSONValue(hbaseData, hbaseDataKey, jsonMappingInfo, splits[splitPosition], repeatPosition, prevJsonObj); // Store data key value into the last JSON object.
			} else {
				JSONObject currentJsonObj = null;
				if (splitPosition == 0) {
					jsonObjKey.append(splits[splitPosition]);
				} else {
					jsonObjKey.append("." + splits[splitPosition]);
				}
				currentJsonObj = createOrRetrieveJSONObject(existingJSONObjects, jsonMappings, existingJSONArrays,
						splits, prevJsonObj, splitPosition, jsonObjKey.toString(), repeatPosition);
				prevJsonObj = currentJsonObj;
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private static JSONObject createOrRetrieveJSONObject(Map<String, JSONObject> existingJSONObjects,
			Map<String, JsonMappingDetails> jsonMappings, Map<String, JSONArray> existingJSONArrays, String[] splits,
			JSONObject prevJsonObj, int splitPosition, String jsonObjKey, int repeatPosition) {
		JSONObject currentJsonObj = new JSONObject();
		if (jsonMappings.containsKey(jsonObjKey) && (jsonMappings.get(jsonObjKey)).isMultipleValues()) {
			JSONArray jsonArray = createOrRetrieveJSONArray(existingJSONArrays, splits, prevJsonObj, jsonObjKey, splitPosition);
			if (!existingJSONObjects.containsKey(jsonObjKey + 0)) {
				jsonArray.add(currentJsonObj);
			} else {
				currentJsonObj = existingJSONObjects.get(jsonObjKey + 0);
			}
			existingJSONObjects.put(jsonObjKey + repeatPosition, currentJsonObj);
		} else {
			if (!existingJSONObjects.containsKey(jsonObjKey)) {
				prevJsonObj.put(splits[splitPosition], currentJsonObj);
				existingJSONObjects.put(jsonObjKey, currentJsonObj);
			} else {
				currentJsonObj = existingJSONObjects.get(jsonObjKey);
			}
		}
		return currentJsonObj;
	}


	@SuppressWarnings("unchecked")
	private static JSONArray createOrRetrieveJSONArray(Map<String, JSONArray> existingJSONArrays, String[] splits,
			JSONObject prevJsonObj, String jsonSearchKey, int splitPosition) {
		JSONArray jsonArray = null;
		if (existingJSONArrays.containsKey(jsonSearchKey)) {
			jsonArray = existingJSONArrays.get(jsonSearchKey);
		} else {
			jsonArray = new JSONArray();
			existingJSONArrays.put(jsonSearchKey, jsonArray);
			prevJsonObj.put(splits[splitPosition], jsonArray);
		}
		return jsonArray;
	}

	@SuppressWarnings("unchecked")
	private static void storeJSONValue(Map<String, String> hbaseData, String key, JsonMappingDetails jsonMappingInfo,
			String splitName, int repeatPosition, JSONObject prevJsonObj) {
		if (!jsonMappingInfo.isMultipleValues()) {
			prevJsonObj.put(splitName, hbaseData.get(key + "~" + repeatPosition));
		} else {
			JSONArray multipleVals = new JSONArray();
			SortedMap<String, String> subMap = getByPrefix(key + "~" + repeatPosition, (NavigableMap<String, String>)hbaseData);
			for (int k=0; k < subMap.size(); k++) {
				multipleVals.add(hbaseData.get(key + "~" + repeatPosition + "~" + k));
			}
			prevJsonObj.put(splitName, multipleVals);
		}
	}

	private static int getNoOfRepeatsFromData(String key, String keyAppender, Map<String, String> hbaseData) {
		return getByPrefix(key + keyAppender, (NavigableMap<String, String>)hbaseData).size();
	}

	public static SortedMap<String, String> getByPrefix(String prefix, NavigableMap<String, String> data) {
	    return data.subMap( prefix, prefix + Character.MAX_VALUE );
	}
	
}