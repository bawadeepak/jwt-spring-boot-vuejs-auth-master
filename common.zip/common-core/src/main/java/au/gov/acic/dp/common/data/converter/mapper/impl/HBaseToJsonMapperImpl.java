package au.gov.acic.dp.common.data.converter.mapper.impl;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.gov.acic.dp.common.data.converter.output.OutputFormat;
import au.gov.acic.dp.common.data.converter.output.impl.OutputFormatJson;
import au.gov.acic.dp.common.data.converter.repository.cache.JsonMappingRepository;

@Component
public class HBaseToJsonMapperImpl extends MapperImpl<Map<String, String>, JSONObject> {

	private static final String JSON_DEPTH = "jsonDepth";
	
	@Autowired
	private JsonMappingRepository jsonMappingRepository;
	
	@Override
	public OutputFormat<JSONObject> performConversion(Map<String, String> input) {
		OutputFormatJson json = new OutputFormatJson();
		json.setOutput(new JSONObject());
		Map<String, JSONObject> existingJSONObjects = new HashMap<String, JSONObject>();
		jsonMappingRepository.getMappingInformation().forEach((key, jsonMappingInfo)  -> {
			createJSON(json.retrieveData(), input, existingJSONObjects, key, jsonMappingInfo);
		});
		return json;
	}

	@SuppressWarnings("unchecked")
	private static void createJSON(JSONObject parentObject, Map<String, String> hbaseData, Map<String, JSONObject> existingJSONObjects, String key, Map<String, String> jsonMappingInfo) {
		String[] splits = null;
		if (jsonMappingInfo.get(JSON_DEPTH).contains("~")) {
			splits = ((jsonMappingInfo.get(JSON_DEPTH).split("~"))[0]).split("[, ?.@]+");
		} else {
			splits = jsonMappingInfo.get(JSON_DEPTH).split("[, ?.@]+");
		}
		String currentKey = "";
		JSONObject prevJsonObj = parentObject;
		for (int i=0; i < splits.length; i++) {
			if (i == (splits.length -1)) {
				prevJsonObj.put(splits[i], hbaseData.get(key));
				break;
			}
			JSONObject currentJsonObj = null;
			if (existingJSONObjects.containsKey(splits[i] + currentKey)) {
				currentJsonObj = existingJSONObjects.get(splits[i]);
			} else {
				currentJsonObj = new JSONObject();
				prevJsonObj.put(splits[i], currentJsonObj);
				existingJSONObjects.put(splits[i], currentJsonObj);
			}
			currentKey = splits[i] + currentKey;
			prevJsonObj = currentJsonObj;
		}
	}

}
