package au.gov.acic.dp.common.security;

import java.text.ParseException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;

import au.gov.acic.dp.common.SecurityConfig;
import au.gov.acic.dp.common.security.model.DataPipelineUser;

@Component
public class JwtUtil {

	private final Logger logger = LoggerFactory.getLogger(JwtUtil.class);

	@Autowired
	private ConfigurableJWTProcessor<SecurityContext> jwtProcessor;

	@Autowired
	private JWSVerifier jwsVerifier;

	public DataPipelineUser validateAndDecodeToken(final String token) {
		DataPipelineUser user = null;
		try {
			final SignedJWT signedJWT = SignedJWT.parse(token);

			if(isSignatureValid(signedJWT)) {
				final JWTClaimsSet jwtClaimsSet = jwtProcessor.process(signedJWT, null);
				final Map<String, Object> claims = jwtClaimsSet.getClaims();
				logger.debug("Claims: {}", claims);
				user = new DataPipelineUser.UserBuilder(jwtClaimsSet.getStringClaim(SecurityConfig.USER_CLAIM_USER_ID))
						.withFirstName(jwtClaimsSet.getStringClaim(SecurityConfig.USER_CLAIM_GIVEN_NAME))
						.withLastName(jwtClaimsSet.getStringClaim(SecurityConfig.USER_CLAIM_FAMILY_NAME))
						.withEmail(jwtClaimsSet.getStringClaim(SecurityConfig.USER_CLAIM_EMAIL))
						.withRoles(jwtClaimsSet.getClaim(SecurityConfig.USER_CLAIM_GROUPS))
						.build();
			}
		} catch (ParseException | JOSEException | BadJOSEException e) {
			logger.debug("Failed to extract user claims from token.", e);
		}
		return user;
	}

	private boolean isSignatureValid(final SignedJWT signedJWT) throws JOSEException {
		return signedJWT.verify(jwsVerifier);
	}

}
