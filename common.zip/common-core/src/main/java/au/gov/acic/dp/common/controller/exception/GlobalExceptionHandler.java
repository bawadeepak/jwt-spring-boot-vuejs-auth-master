package au.gov.acic.dp.common.controller.exception;

import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.Nullable;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.util.WebUtils;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import au.gov.acic.dp.common.controller.model.ApiResponse;
import au.gov.acic.dp.common.controller.model.ErrorResponse;

public class GlobalExceptionHandler {

	private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleAll(final Exception ex, final WebRequest request) {
		final ApiResponse response = buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, null);
		logException(this.getClass().getName(), ex);
		return handleExceptionInternal(ex, response, new HttpHeaders(), response.getStatus(), request);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Object> handleConstraintViolationException(final ConstraintViolationException ex) {
		logException(this.getClass().getName(), ex);
		final Map<String, List<String>> errorMap = ex.getConstraintViolations().stream()
				.collect(Collectors.groupingBy(cv -> cv.getPropertyPath().toString(), Collectors.mapping(cv -> cv.getMessage(), Collectors.toList())));
		final List<String> errorList = errorMap.get("");
		final ErrorResponse response = buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), errorList, errorMap);
		return new ResponseEntity<>(response, response.getStatus());
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<Object> handleHttpMessageNotReadableException(final HttpMessageNotReadableException ex, final WebRequest request) throws Exception {
		logException(this.getClass().getName(), ex);
		String error = ex.getMessage();
		if(ex.getRootCause() instanceof DateTimeParseException) {
			error = ex.getRootCause().getMessage();
		}
		if(ex.getCause() instanceof InvalidFormatException) {
			error = ex.getCause().getMessage();
		}
		final ErrorResponse response = buildErrorResponse(HttpStatus.BAD_REQUEST,
				"HttpMessageNotReadableException encountered.",
				Collections.singletonList(error),
				null);
		return handleExceptionInternal(ex, response, new HttpHeaders(), response.getStatus(), request);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleMethodArgumentNotValidException(final MethodArgumentNotValidException ex) {
		logException(this.getClass().getName(), ex);
		final ErrorResponse response = mapBindingResult(ex.getMessage(), ex.getBindingResult());
		return new ResponseEntity<>(response, response.getStatus());
	}

	@ExceptionHandler(MissingServletRequestPartException.class)
	public ResponseEntity<Object> handleMissingServletRequestPartException(final MissingServletRequestPartException ex, final WebRequest request) throws Exception {
		logException(this.getClass().getName(), ex);
		final ErrorResponse response = buildErrorResponse(HttpStatus.BAD_REQUEST, "MissingServletRequestPartException: " + ex.getMessage(), Collections.singletonList(ex.getMessage()), null);
		return handleExceptionInternal(ex, response, new HttpHeaders(), response.getStatus(), request);
	}

	@ExceptionHandler(ServletRequestBindingException.class)
	public ResponseEntity<Object> handleServletRequestBindingException(final ServletRequestBindingException ex, final WebRequest request) throws Exception {
		logException(this.getClass().getName(), ex);
		final ErrorResponse response = buildErrorResponse(HttpStatus.BAD_REQUEST, "ServletRequestBindingException: " + ex.getMessage(), Collections.singletonList(ex.getMessage()), null);
		return handleExceptionInternal(ex, response, new HttpHeaders(), response.getStatus(), request);
	}

	private ErrorResponse mapBindingResult(final String errorMessage, final BindingResult bindingResult) {
		final List<String> errorList = bindingResult.getGlobalErrors().stream()
				.collect(Collectors.mapping(ObjectError::getDefaultMessage, Collectors.toList()));
		final Map<String, List<String>> errorMap = bindingResult.getFieldErrors().stream()
				.collect(Collectors.groupingBy(FieldError::getField, Collectors.mapping(FieldError::getDefaultMessage, Collectors.toList())));
		return buildErrorResponse(HttpStatus.BAD_REQUEST,
				errorMessage,
				errorList,
				errorMap);
	}

	protected ErrorResponse buildErrorResponse(final HttpStatus status, final String message, final List<String> errors, final Map<String, List<String>> fieldErrors) {
		return new ErrorResponse(status, message)
				.setErrors(errors)
				.setFieldErrors(fieldErrors);
	}

	protected ResponseEntity<Object> handleExceptionInternal(
			final Exception ex, @Nullable final Object body, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

		if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
		}
		return new ResponseEntity<>(body, headers, status);
	}

	protected void logException(final String context, final Exception ex) {
		logger.error("{}: {}, {}", context, ex.getClass(), ex.getMessage(), ex);
	}

}
