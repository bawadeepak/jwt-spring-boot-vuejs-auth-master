package au.gov.acic.dp.common.model.metadata;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import au.gov.acic.dp.common.model.metadata.Security.Classification;
import au.gov.acic.dp.common.model.metadata.Security.DLM;

import java.util.Objects;

public class SecurityValidator implements ConstraintValidator<ValidSecurity, Metadata> {

	@Override
	public boolean isValid(final Metadata value, final ConstraintValidatorContext context) {
		final Security security = value.getSecurity();
		if(Objects.isNull(security) || Objects.isNull(security.getDlm())) {
			return true;
		}
		if (( (DLM.FOUO.equals(security.getDlm()) && !Classification.UNCLASSIFIED.equals(security.getClassification()))
				|| (DLM.CABINET.equals(security.getDlm()) && !Classification.PROTECTED.equals(security.getClassification())))) {
			return false;
		}
		return true;
	}

}
