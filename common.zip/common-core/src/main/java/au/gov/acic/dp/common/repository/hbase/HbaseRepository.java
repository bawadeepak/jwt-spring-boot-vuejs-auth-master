package au.gov.acic.dp.common.repository.hbase;

import java.util.List;

import au.gov.acic.dp.common.repository.hbase.model.HbaseRecord;

public interface HbaseRepository {

	public static final String DELIMITER = "~";
	public static final String POLE_OBJECT_SUFFIX = "O";
	public static final String FAMILY_RAW_DATA = "rd";
	public static final String COLUMN_QUALIFIER_PREFIX_FILE = "file" + DELIMITER;

	void saveRecord(HbaseRecord record);
	HbaseRecord getRecord(String tableName, String familyName, String rowKey, List<String> columnQualifiers);
	byte[] getCellValue(String tableName, String familyName, String rowKey, String columnQualifier);
}
