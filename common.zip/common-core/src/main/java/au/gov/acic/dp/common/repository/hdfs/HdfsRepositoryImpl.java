package au.gov.acic.dp.common.repository.hdfs;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

@Profile("hdfs")
@Repository
public class HdfsRepositoryImpl implements HdfsRepository {

	private final Logger logger = LoggerFactory.getLogger(HdfsRepositoryImpl.class);

	@Autowired
	private FileSystem fileSystem;

	@Autowired
	private Configuration configuration;

	@Override
	public void save(final String dataFilePath, final InputStream dataInputStream) throws IOException {
		logger.debug("Saving file: {}", dataFilePath);
		final long startTime = System.currentTimeMillis();
		writeToHdfs(dataFilePath, dataInputStream);
		final long timeTaken = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTime);
		logger.debug("Time taken to write to HDFS(Seconds): {}", timeTaken);
	}

	@Override
	public InputStream getFile(final String dataFilePath) throws IOException {
		logger.debug("Downloading file: {}", dataFilePath);
		final Path fspath = new Path(dataFilePath);
		return fileSystem.open(fspath);
	}

	private void writeToHdfs(final String hdfsPath, final InputStream data) throws IOException {
		logger.debug("FS Status: {}", fileSystem.getStatus());
		final Path fspath = new Path(hdfsPath);
		final FSDataOutputStream fos = fileSystem.create(fspath, true);
		final InputStream is = new BufferedInputStream(data);
		IOUtils.copyBytes(is, fos, configuration);
	}

}
