package au.gov.acic.dp.common.repository.kafka.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Profile("kafka")
@Component
public class KafkaSender {

	private final Logger logger = LoggerFactory.getLogger(KafkaSender.class);

	@Autowired
	private KafkaTemplate<String, ?> kafkaTemplate;

	public void send(final String topic, final Message<?> payload) {
		logger.debug("Sending message {} to topic {}.", payload, topic);
		kafkaTemplate.setDefaultTopic(topic);
		kafkaTemplate.send(payload);
	}

}
