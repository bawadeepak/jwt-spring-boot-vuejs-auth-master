package au.gov.acic.dp.common.data.converter.repository.cache.model;

import lombok.Data;

@Data
public class JsonMappingDetails {
	
	private String displayName;
	private String converter;
	private String jsonDepth;
	private String jsonFieldName;
	private String dataSourceKey;
	private boolean isMultipleValues;
	private boolean objectTree;
	
}
