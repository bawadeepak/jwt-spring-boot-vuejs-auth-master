package au.gov.acic.dp.common.data.converter.output;

public interface OutputFormat<O> {

	O retrieveData();
	
}
