package au.gov.acic.dp.common.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper=false)
public class SuccessResponse<T> extends ApiResponse {

	private List<T> data;

	public SuccessResponse() {
		this(HttpStatus.OK, null);
	}

	public SuccessResponse(final String message) {
		this(HttpStatus.OK, message);
	}

	public SuccessResponse(final HttpStatus status, final String message) {
		super(status, message);
	}

	public SuccessResponse<T> setData(final List<T> data) {
		this.data = data;
		return this;
	}
}

