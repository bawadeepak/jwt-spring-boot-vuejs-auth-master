package au.gov.acic.dp.common;

import au.gov.acic.dp.common.util.DateUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.TimeZone;

@SpringBootApplication
public class CommonCoreApplication {

	public static void main(final String[] args) {
		SpringApplication.run(CommonCoreApplication.class, args);
	}

	@Bean
	public MessageSource messageSource() {
		final ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("ValidationMessages");
		return messageSource;
	}

	@Bean
	public ObjectMapper getObjectMapper() {
		final ObjectMapper mapper =  new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		mapper.setDateFormat(DateUtil.getDefaultDateFormat());
		mapper.setTimeZone(TimeZone.getDefault());
		return mapper;
	}
}
