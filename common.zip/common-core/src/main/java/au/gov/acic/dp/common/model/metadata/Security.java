package au.gov.acic.dp.common.model.metadata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
public class Security {

	private static final String GROUP_SUFFIX = "group";

	public enum Classification {
		UNCLASSIFIED, PROTECTED
	}

	public enum DLM {
		@JsonProperty("For Official Use Only") FOUO,
		@JsonProperty("Sensitive") SENSITIVE,
		@JsonProperty("Sensitive: Cabinet") CABINET,
		@JsonProperty("Sensitive: Personal") PERSONAL,
		@JsonProperty("Sensitive: Legal") LEGAL
	}

	public enum Caveat {
		NSWPFEO, VICPOLEO, ACICEO
	}

	private Classification classification = Classification.UNCLASSIFIED;
	private DLM dlm = DLM.FOUO;
	private Caveat caveat;

	@JsonIgnore
	public List<String> getReadGroups() {
		final List<String> readGroups = new ArrayList<>();
		if (Objects.isNull(getCaveat())) {
			readGroups.add(String.join("_", getClassification().toString(), GROUP_SUFFIX).toLowerCase());
		} else {
			readGroups.add(
					String.join("_", getClassification().toString(), getCaveat().toString(), GROUP_SUFFIX)
					.toLowerCase());
		}
		return readGroups;
	}

}
