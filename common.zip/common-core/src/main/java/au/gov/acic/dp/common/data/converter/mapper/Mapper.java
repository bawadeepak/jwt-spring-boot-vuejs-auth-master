package au.gov.acic.dp.common.data.converter.mapper;

public interface Mapper<I, O> {

	O convert(I inputSource);
	
}
