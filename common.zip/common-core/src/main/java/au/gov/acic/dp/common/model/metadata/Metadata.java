package au.gov.acic.dp.common.model.metadata;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import java.time.LocalDate;

@Data
@ValidSecurity
public class Metadata {

	public enum ResourceType {
		@JsonProperty("Collection") COLLECTION,
		@JsonProperty("Dataset") DATASET,
		@JsonProperty("Event") EVENT,
		@JsonProperty("Image") IMAGE,
		@JsonProperty("InteractiveResource") INTERATIVERESOURCE,
		@JsonProperty("MovingImage") MOVINGIMAGE,
		@JsonProperty("PhysicalObject") PHYSICALOBJECT,
		@JsonProperty("Service") SERVICE,
		@JsonProperty("Software") SOFTWARE,
		@JsonProperty("Sound") SOUND,
		@JsonProperty("StillImage") STILLIMAGE,
		@JsonProperty("Text") TEXT;
	}

	public enum MimeType {
		@JsonProperty("text/csv") CSV("text/csv"),
		@JsonProperty("text/plain") PLAIN("text/plain");

		private String displayText;

		private MimeType(final String displayText) {
			this.displayText = displayText;
		}

		public String displayText() {
			return displayText;
		}
	}

	@Length(min=5, max=255, message="{title.length}")
	@NotEmpty(message="{title.empty}")
	private String title;

	@NotNull(message="{extractionDate.null}")
	@PastOrPresent(message="{extractionDate.pastOrPresent}")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@JsonFormat (shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate extractionDate;

	@NotNull(message="{resourceType.null}")
	private ResourceType resourceType;

	@NotNull(message="{mimeType.null}")
	private MimeType mimeType;

	@Length(min=1, max=255, message="{dataFormatType.length}")
	private String dataFormatType = "ADHOC";

	private Double dataFormatVersion = 1.0;

	private Source source;

	private Security security = new Security();

	private SystemData systemData;

}
