package au.gov.acic.dp.common.security.model;

import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
public class DataPipelineUser {

	private String username;
	private String firstName;
	private String lastName;
	private String email;
	private String organisation;
	private List<String> roles;

	public DataPipelineUser(final UserBuilder builder) {
		super();
		username = builder.username;
		firstName = builder.firstName;
		lastName = builder.lastName;
		email = builder.email;
		organisation = builder.organisation;
		roles = builder.roles;
	}

	public static class UserBuilder {

		private final String username;
		private String firstName;
		private String lastName;
		private String email;
		private String organisation;
		private List<String> roles;

		public UserBuilder(final String username) {
			this.username = username;
		}

		public UserBuilder withFirstName(final String firstName) {
			this.firstName = firstName;
			return this;
		}

		public UserBuilder withLastName(final String lastName) {
			this.lastName = lastName;
			return this;
		}

		public UserBuilder withEmail(final String email) {
			this.email = email;
			return this;
		}

		public UserBuilder withOrganisation(final String organisation) {
			this.organisation = organisation;
			return this;
		}

		@SuppressWarnings("unchecked")
		public UserBuilder withRoles(final Object roles) {
			//convert the AD roles to list of App roles
			if(roles instanceof String) {
				this.roles = Collections.singletonList((String)roles);
			} else {
				this.roles = (List<String>)roles;
			}

			return this;
		}

		public DataPipelineUser build() {
			return new DataPipelineUser(this);
		}
	}

}
