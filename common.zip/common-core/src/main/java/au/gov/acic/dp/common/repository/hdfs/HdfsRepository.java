package au.gov.acic.dp.common.repository.hdfs;

import java.io.IOException;
import java.io.InputStream;


public interface HdfsRepository {

	void save(final String dataFilePath, InputStream dataInputStream) throws IOException;

	InputStream getFile(final String dataFilePath) throws IOException;

}
