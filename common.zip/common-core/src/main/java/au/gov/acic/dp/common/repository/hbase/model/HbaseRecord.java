package au.gov.acic.dp.common.repository.hbase.model;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HbaseRecord {

	public String tableName;
	public String familyName;
	public Map<String, HbaseColumn> columns = new HashMap<>();

}
