package au.gov.acic.dp.common.data.converter.input;

public interface InputSource<I> {

	I retrieveData();
	
}
