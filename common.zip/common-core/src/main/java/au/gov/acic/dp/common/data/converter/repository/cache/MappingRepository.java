package au.gov.acic.dp.common.data.converter.repository.cache;

public interface MappingRepository<M> {
	
	public M getMappingInformation();
}
