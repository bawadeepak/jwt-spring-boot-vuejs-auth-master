package au.gov.acic.dp.common.model.validation;

import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.util.ObjectUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;

public class DateRangeValidator implements ConstraintValidator<DateRange, Object> {

	private static final SpelExpressionParser PARSER = new SpelExpressionParser();

	private String start;
	private String end;

	@Override
	public void initialize(final DateRange constraintAnnotation) {
		start = constraintAnnotation.start();
		end = constraintAnnotation.end();
	}

	@Override
	public boolean isValid(final Object value, final ConstraintValidatorContext context) {
		final Object startValue = PARSER.parseExpression(start).getValue(value);
		final Object endValue = PARSER.parseExpression(end).getValue(value);

		if (ObjectUtils.isEmpty(startValue) || ObjectUtils.isEmpty(endValue)) {
			return true;
		}

		if (!(startValue instanceof LocalDate)
				|| !(endValue instanceof LocalDate)) {
			throw new IllegalArgumentException("Illegal method signature, expected two parameters of type LocalDate.");
		}

		final LocalDate startDate = (LocalDate)startValue;
		final LocalDate endDate = (LocalDate)endValue;

		return !startDate.isAfter(endDate);
	}

}
