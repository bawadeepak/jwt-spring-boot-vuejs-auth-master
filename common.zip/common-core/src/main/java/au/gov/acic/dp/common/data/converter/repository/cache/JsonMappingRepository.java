package au.gov.acic.dp.common.data.converter.repository.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import au.gov.acic.dp.common.data.converter.repository.cache.model.JsonMappingDetails;

@Repository
public class JsonMappingRepository implements MappingRepository<Map<String, Map<String, String>>> {

	public static final String DISPLAY_NAME = "displayName";
	public static final String JSON_DEPTH = "jsonDepth";
	public static final String CONVERTER = "displayName";
	public static final String JSON_FIELD_NAME = "jsonFieldName";
	public static final String MUTLIPLE = "hasMultiple";
	

	@Override
	@Cacheable("jsonMapping")
	public Map<String, Map<String, String>> getMappingInformation() {
		return getJSONObjectMapping();
	}
	
	private static Map<String, Map<String, String>> getJSONObjectMapping() {
		Map<String, Map<String, String>> mappingsMap = new HashMap<String, Map<String, String>>();
		Map<String, JsonMappingDetails> jsonMappingsMap = new HashMap<String, JsonMappingDetails>();
		Map<String, String> mappings = getJSONObjectMappingData();
		mappings.forEach((parameterKey, parameterValue) -> {
			StringTokenizer tokens = new StringTokenizer(parameterKey, ".");
			String hbaseKey = tokens.nextToken();
			String property = tokens.nextToken();
			Map<String, String> mappingDetails = null;
			JsonMappingDetails jsonMappingDetails = null;
			if (!mappingsMap.containsKey(hbaseKey)) {
				mappingDetails = new HashMap<String, String>();
				jsonMappingDetails = new JsonMappingDetails();
				mappingsMap.put(hbaseKey, mappingDetails);
				jsonMappingsMap.put(hbaseKey, jsonMappingDetails);
			} else {
				mappingDetails = mappingsMap.get(hbaseKey);
			}
			mappingDetails.put(property, parameterValue);
			storeMappingDetails(jsonMappingDetails, property, parameterValue);
	    });
		return mappingsMap;
	}
	
	private static void storeMappingDetails(JsonMappingDetails jsonMappingDetails, String property,
			String parameterValue) {
		if (property.equalsIgnoreCase(DISPLAY_NAME)) {
			jsonMappingDetails.setDisplayName(parameterValue);
		} else if (property.equalsIgnoreCase(JSON_DEPTH)) {
			jsonMappingDetails.setJsonDepth(parameterValue);
		} if (property.equalsIgnoreCase(CONVERTER)) {
			jsonMappingDetails.setConverter(parameterValue);
		} if (property.equalsIgnoreCase(JSON_FIELD_NAME)) {
			jsonMappingDetails.setJsonFieldName(parameterValue);
		} if (property.equalsIgnoreCase(MUTLIPLE)) {
			jsonMappingDetails.setMultipleValues(parameterValue.equalsIgnoreCase("true")? true : false);
		} 
	}

	private static Map<String, String> getJSONObjectMappingData() {
		Map<String, String> mappingData = new HashMap<String, String>();
		mappingData.put("P~alias~nameType.displayName", "Type of Name");
		mappingData.put("P~alias~nameType.converter", "SentenceCase");
		mappingData.put("P~alias~nameType.jsonDepth", "person.alias");
		mappingData.put("P~alias~nameType.jsonFieldName", "NameType");
		mappingData.put("P~alias~nameType.multiple", "true");
		mappingData.put("P~alias~givenName.displayName", "Given Name");
		mappingData.put("P~alias~givenName.converter", "SentenceCase");
		mappingData.put("P~alias~givenName.jsonDepth", "person.givenName");
		mappingData.put("P~alias~givenName.jsonFieldName", "GivenNameType");
		mappingData.put("P~alias~givenName.multiple", "true");
		mappingData.put("O~file~id.displayName", "Given Name");
		mappingData.put("O~file~id.converter", "SentenceCase");
		mappingData.put("O~file~id.jsonDepth", "object.file");
		mappingData.put("O~file~id.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~id.multiple", "false");
		mappingData.put("O~file~type.displayName", "Given Name");
		mappingData.put("O~file~type.converter", "SentenceCase");
		mappingData.put("O~file~type.jsonDepth", "object.file");
		mappingData.put("O~file~type.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~type.multiple", "false");
		mappingData.put("O~file~content.displayName", "Given Name");
		mappingData.put("O~file~content.converter", "SentenceCase");
		mappingData.put("O~file~content.jsonDepth", "object.content");
		mappingData.put("O~file~content.jsonFieldName", "GivenNameType");
		mappingData.put("O~file~content.multiple", "false");
		return mappingData;
	}
	
//	private static Map<String, String> getJSONObjectMappingData() {
//		Map<String, String> mappingData = new HashMap<String, String>();
//		mappingData.put("1.displayName", "Type of Name");
//		mappingData.put("1.converter", "SentenceCase");
//		mappingData.put("1.jsonDepth", "person.alias");
//		mappingData.put("1.jsonFieldName", "NameType");
//		mappingData.put("1.dataSourceFieldKey", "P~alias~nameType");
//		mappingData.put("2.displayName", "Given Name");
//		mappingData.put("2.converter", "SentenceCase");
//		mappingData.put("2.jsonDepth", "person.givenName");
//		mappingData.put("2.jsonFieldName", "GivenNameType");
//		mappingData.put("2.dataSourceFieldKey", "P~alias~givenName");
//		mappingData.put("3.displayName", "Given Name");
//		mappingData.put("3.converter", "SentenceCase");
//		mappingData.put("3.jsonDepth", "object.file");
//		mappingData.put("3.jsonFieldName", "object.file");
//		mappingData.put("3.dataSourceFieldKey", "O~file~ id");
//		mappingData.put("4.displayName", "Given Name");
//		mappingData.put("4.converter", "SentenceCase");
//		mappingData.put("4.jsonDepth", "object.file");
//		mappingData.put("4.jsonFieldName", "GivenNameType");
//		mappingData.put("4.dataSourceFieldKey", "O~file~type");
//		mappingData.put("5.displayName", "Given Name");
//		mappingData.put("5.converter", "SentenceCase");
//		mappingData.put("5.jsonDepth", "object.content");
//		mappingData.put("5.jsonFieldName", "GivenNameType");
//		mappingData.put("5.dataSourceFieldKey", "O~file~content");
//		return mappingData;
//	}
	
}