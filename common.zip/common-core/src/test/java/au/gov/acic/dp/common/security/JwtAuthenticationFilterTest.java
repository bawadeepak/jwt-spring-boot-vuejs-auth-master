package au.gov.acic.dp.common.security;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;

import au.gov.acic.dp.common.SecurityConfig;
import au.gov.acic.dp.common.security.model.DataPipelineUser;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JwtAuthenticationFilterTest {

	private JwtAuthenticationFilter jwtAuthenticationFilter;

	@Test
	public void testValidateAndDecodeToken() throws Exception {
		final String token = "eyJ4NXQiOiJZbU5tT1RJeE1qWTFOR1F3TVdJMk5qVm1NelprTVdGbU5tRTBNek5tWkRVd01HUXhOall3WlEiLCJraWQiOiJZbU5tT1RJeE1qWTFOR1F3TVdJMk5qVm1NelprTVdGbU5tRTBNek5tWkRVd01HUXhOall3WlEiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJzX3VzZXIxQG5pcy10dGEtcGFydG5lci5sb2NhbCIsImlzcyI6Imh0dHBzOlwvXC9uaXNtMDAxczo5NDQzXC9vYXV0aDJcL3Rva2VuIiwiZ3JvdXBzIjoiRFAtUkVBTE1cL0RQU3RhbmRhcmRVc2VyIiwiZ2l2ZW5fbmFtZSI6InNfdXNlcjEiLCJ1c2VyaWQiOiJzX3VzZXIxIiwiYXVkIjoiblFvRXQ2Sm5qWWtWVlFmV2Fva0xkeF84R2lvYSIsImF6cCI6Im5Rb0V0NkpuallrVlZRZldhb2tMZHhfOEdpb2EiLCJzY29wZSI6Im9wZW5pZCIsImV4cCI6MTUzNDgyMzkxMywiaWF0IjoxNTM0ODIwMzEzLCJNdWx0aUF0dHJpYnV0ZVNlcGFyYXRvciI6W10sImZhbWlseV9uYW1lIjoic19sbmFtZTEiLCJqdGkiOiI0ZjFiMjUxZC1iMWJkLTQ5ZmYtYjQ0ZS1kOTA3ZDdhNTQ2MDQiLCJlbWFpbCI6InNfdXNlcjEuc19sbmFtZTFAbmlzLXR0YS1wYXJ0bmVyLmxvY2FsIn0.GnMtQPi9cCY4py8HjxCuTi1OP-etRtpVPH8CnP9sED2F8aSHa5JPg1GikHlAqx4GpGAOIr-QGtcMxovepILUQplYfXtx9vy-FwIft1x2QrsiHOt3GjFHNAa31R4JAJOa2dVYX2fEMF0oaQYqFTimJwCfluj8OQSvT3TKEb7MXN8Mii3td3EfNpfgK95Ed6wMZ1WEMLU0-3iS3vjHZ3LD0F2rYTpMrM2x2le8utE6PJVGGgcj6Ox6SnyXX5jgSYxm3p5AoT2uCgJCHJTAAEwFHrt-PZrimm3XoB5ijyUOhqI_Ki3HdrQ6mGGUo7niRCwsH2pra9YPkUDaLeRLp_uDoQ";
		final JwtUtil mockJwtUtil = Mockito.mock(JwtUtil.class);
		Mockito.when(mockJwtUtil.validateAndDecodeToken(token)).thenReturn(new DataPipelineUser.UserBuilder("username").build());
		final HttpServletRequest mockReq =  Mockito.mock(HttpServletRequest.class);
		Mockito.when(mockReq.getHeader(SecurityConfig.HEADER_JWT)).thenReturn(token);

		jwtAuthenticationFilter = new JwtAuthenticationFilter(mockJwtUtil);
		jwtAuthenticationFilter.doFilter(mockReq, new MockHttpServletResponse(), new MockFilterChain());
	}
}
