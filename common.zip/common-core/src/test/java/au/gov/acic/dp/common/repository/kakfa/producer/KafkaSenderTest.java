package au.gov.acic.dp.common.repository.kakfa.producer;

import java.time.LocalDate;
import java.util.Collections;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import au.gov.acic.dp.common.model.metadata.Metadata;
import au.gov.acic.dp.common.model.metadata.SecurityTag;
import au.gov.acic.dp.common.model.metadata.SystemData;
import au.gov.acic.dp.common.repository.kafka.producer.KafkaSender;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("kafka")
public class KafkaSenderTest {

	@MockBean
	private KafkaTemplate<String, ?> kafkaTemplate;

	@Autowired
	private KafkaSender sender;

	@Test
	public void testSend() throws Exception {
		Mockito.when(kafkaTemplate.send(Mockito.any(GenericMessage.class))).thenReturn(null);
		sender.send("test-topic", new GenericMessage<>(getMockMetadata()));
	}

	private MockMetadata getMockMetadata() {
		final MockMetadata md = new MockMetadata();
		md.setTitle("title");
		final SystemData sd =  new SystemData("abc123", null, "RawData", "rd", "abc123~O", "abc12s~file", null, "valid.csv", "username", "test@email.com", LocalDate.now(), new SecurityTag(Collections.emptyList(), 1));
		md.setSystemData(sd);
		return md;
	}

	private class MockMetadata extends Metadata {

	}

}
