package au.gov.acic.dp.common;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import au.gov.acic.dp.common.data.converter.mapper.impl.HBaseToJsonMapperTest;
import au.gov.acic.dp.common.data.converter.repository.cache.PropertiesRepository;
import au.gov.acic.dp.common.data.converter.repository.cache.model.JsonMappingDetails;

@Configuration
@Profile("test")
public class TestConfiguration {
	
    @Bean
    @Primary
    public PropertiesRepository propertiesRepository() {
        return new TestPropertiesRepository();
    }

    public static class TestPropertiesRepository extends PropertiesRepository {
    	private String testName;
    	public void setExecutingTestName(String testName) {
    		this.testName = testName;
    	}
		@Override
		public Map<String, JsonMappingDetails> getMappingInformation() {
			if (testName.equals(HBaseToJsonMapperTest.TEST_PERSON_ALIAS_ONLY)) {
				return getJSONPersonAliasOnlyMappingData();
			} else if (testName.equals(HBaseToJsonMapperTest.TEST_PERSON_ALIAS_DETAILS)) {
				return getJSONPersonAliasDetailsMappingData();
			} else if (testName.equals(HBaseToJsonMapperTest.TEST_PERSON_AND_OBJECT)) {
				return getJSONPersonAndObjectMappingData();
			} else if (testName.equals(HBaseToJsonMapperTest.TEST_CALL_DATA)) {
				return getJSONCallsMappingData();
			}
			return null;
		}
	}

	private static Map<String, JsonMappingDetails> getJSONCallsMappingData() {
		Map<String, JsonMappingDetails> mappingData = new LinkedHashMap<String, JsonMappingDetails>();

		JsonMappingDetails jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links");
		jsonMappingDetails.setDataSourceKey("E~links");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("links", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.nodeOne.number");
		jsonMappingDetails.setDataSourceKey("E~links~aPartyNumber");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("links.nodeOne.number", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.nodeOne.localRefId");
		jsonMappingDetails.setDataSourceKey("E~links~localRefId");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("links.nodeOne.localRefId", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.nodeTwo.number");
		jsonMappingDetails.setDataSourceKey("E~links~bPartyNumber");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("links.nodeTwo.number", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.nodeTwo.number");
		jsonMappingDetails.setDataSourceKey("E~links~bPartyNumber");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("links.nodeTwo.number", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.calls");
		jsonMappingDetails.setDataSourceKey("E~links~calls");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("links.calls", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.calls.callDate");
		jsonMappingDetails.setDataSourceKey("E~links~calls~CallDate");
		jsonMappingDetails.setMultipleValues(false);
		jsonMappingDetails.setObjectTree(true);
		mappingData.put("links.calls.callDate", jsonMappingDetails);
		
		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setJsonDepth("links.calls.investigation");
		jsonMappingDetails.setDataSourceKey("E~links~calls~investigation");
		jsonMappingDetails.setMultipleValues(false);
		jsonMappingDetails.setObjectTree(true);
		mappingData.put("links.calls.investigation", jsonMappingDetails);
		
		return mappingData;
	}

	private static Map<String, JsonMappingDetails> getJSONPersonAliasOnlyMappingData() {
		Map<String, JsonMappingDetails> mappingData = new LinkedHashMap<String, JsonMappingDetails>();

		JsonMappingDetails jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setDisplayName("Aliases");
		jsonMappingDetails.setJsonDepth("person.alias");
		jsonMappingDetails.setDataSourceKey("P~alias");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("person.alias", jsonMappingDetails);
		
		return mappingData;
	}

	private static Map<String, JsonMappingDetails> getJSONPersonAliasDetailsMappingData() {
		Map<String, JsonMappingDetails> mappingData = new LinkedHashMap<String, JsonMappingDetails>();

		JsonMappingDetails jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setDisplayName("Aliases");
		jsonMappingDetails.setJsonDepth("person.alias");
		jsonMappingDetails.setDataSourceKey("P~alias");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("person.alias", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Type of Name");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.nameType");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setDataSourceKey("P~alias~nameType");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.alias.nameType", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Given Name");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.givenName");
		jsonMappingDetails.setJsonFieldName("GivenNameType");
		jsonMappingDetails.setDataSourceKey("P~alias~givenName");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("person.alias.givenName", jsonMappingDetails);
		
		return mappingData;
	}

	private static Map<String, JsonMappingDetails> getJSONPersonAndObjectMappingData() {
		Map<String, JsonMappingDetails> mappingData = new LinkedHashMap<String, JsonMappingDetails>();

		JsonMappingDetails jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setDisplayName("Aliases");
		jsonMappingDetails.setJsonDepth("person.alias");
		jsonMappingDetails.setDataSourceKey("P~alias");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("person.alias", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Type of Name");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.nameType");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setDataSourceKey("P~alias~nameType");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.alias.nameType", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("DB Source");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.db.source");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setDataSourceKey("P~alias~DB~source");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.alias.db.source", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("DB Source");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.db.type");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setDataSourceKey("P~alias~DB~type");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.alias.db.type", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Given Name");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.alias.givenName");
		jsonMappingDetails.setJsonFieldName("GivenNameType");
		jsonMappingDetails.setDataSourceKey("P~alias~givenName");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("person.alias.givenName", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Height");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.physicalDescription.height");
		jsonMappingDetails.setJsonFieldName("Height");
		jsonMappingDetails.setDataSourceKey("P~physicalDescription~height");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.physicalDescription.height", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Weight");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("person.physicalDescription.weight");
		jsonMappingDetails.setJsonFieldName("Weight");
		jsonMappingDetails.setDataSourceKey("P~physicalDescription~weight");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("person.physicalDescription.weight", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Object File");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("object.file");
		jsonMappingDetails.setJsonFieldName("NameType");
		jsonMappingDetails.setDataSourceKey("O~file");
		jsonMappingDetails.setMultipleValues(true);
		mappingData.put("object.file", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Object File Id");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("object.file.id");
		jsonMappingDetails.setJsonFieldName("ObjectFileId");
		jsonMappingDetails.setDataSourceKey("O~file~id");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("object.file.id", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Object File Type");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("object.file.type");
		jsonMappingDetails.setJsonFieldName("ObjectFileId");
		jsonMappingDetails.setDataSourceKey("O~file~type");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("object.file.type", jsonMappingDetails);

		jsonMappingDetails = new JsonMappingDetails();
		jsonMappingDetails.setDisplayName("Object File Content");
		jsonMappingDetails.setConverter("SentenceCase");
		jsonMappingDetails.setJsonDepth("object.file.content");
		jsonMappingDetails.setJsonFieldName("ObjectFileId");
		jsonMappingDetails.setDataSourceKey("O~file~content");
		jsonMappingDetails.setMultipleValues(false);
		mappingData.put("object.file.content", jsonMappingDetails);
		
		return mappingData;
	}

}