package au.gov.acic.dp.common.data.converter.mapper.impl;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import au.gov.acic.dp.common.TestConfiguration.TestPropertiesRepository;
import au.gov.acic.dp.common.data.converter.input.impl.InputSourceHBase;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class HBaseToJsonMapperTest {


	private final Logger LOG = LoggerFactory.getLogger(HBaseToJsonMapperTest.class);
    
    public static final String TEST_PERSON_ALIAS_ONLY = "testPersonAliasOnly";
    public static final String TEST_PERSON_ALIAS_DETAILS = "testPersonAliasDetails";
    public static final String TEST_PERSON_AND_OBJECT = "testPersonAndObject";
    public static final String TEST_CALL_DATA = "testCallData";

    @Autowired
	private HBaseToJsonMapper hBaseToJsonMapper;
    
    @Autowired
    private TestPropertiesRepository testPropertiesRepository;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testCallData() {
		testPropertiesRepository.setExecutingTestName(TEST_CALL_DATA);
		JSONObject json = hBaseToJsonMapper.convert(new InputSourceHBase());
		LOG.debug(json.toJSONString());
		Assert.assertNotNull("JSON object should not be null", json);
		Assert.assertTrue("JSON does not contain required data:" + "alias", json.toJSONString().contains("alias"));
		Assert.assertTrue("JSON does not contain required data:" + "nameType", json.toJSONString().contains("nameType"));
		Assert.assertTrue("JSON does not contain required data:" + "object", json.toJSONString().contains("object"));
	}
	
	@Test
	public void testPersonAliasOnly() {
		testPropertiesRepository.setExecutingTestName(TEST_PERSON_ALIAS_ONLY);
		JSONObject json = hBaseToJsonMapper.convert(new InputSourceHBase());
		LOG.debug(json.toJSONString());
		Assert.assertNotNull("JSON object should not be null", json);
		Assert.assertTrue("JSON does not contain required data:" + "alias", json.toJSONString().contains("alias"));
		Assert.assertFalse("JSON does not contain required data:" + "nameType", json.toJSONString().contains("nameType"));
		Assert.assertFalse("JSON does not contain required data:" + "object", json.toJSONString().contains("object"));
	}
	
	@Test
	public void testPersonAliasDetails() {
		testPropertiesRepository.setExecutingTestName(TEST_PERSON_ALIAS_DETAILS);
		JSONObject json = hBaseToJsonMapper.convert(new InputSourceHBase());
		LOG.debug(json.toJSONString());
		Assert.assertNotNull("JSON object should not be null", json);
		Assert.assertTrue("JSON does not contain required data:" + "alias", json.toJSONString().contains("alias"));
		Assert.assertTrue("JSON does not contain required data:" + "nameType", json.toJSONString().contains("nameType"));
		Assert.assertFalse("JSON does not contain required data:" + "object", json.toJSONString().contains("object"));
	}
	
	@Test
	public void testPersonAndObject() {
		testPropertiesRepository.setExecutingTestName(TEST_PERSON_AND_OBJECT);
		JSONObject json = hBaseToJsonMapper.convert(new InputSourceHBase());
		LOG.debug(json.toJSONString());
		Assert.assertNotNull("JSON object should not be null", json);
		Assert.assertTrue("JSON does not contain required data:" + "alias", json.toJSONString().contains("alias"));
		Assert.assertTrue("JSON does not contain required data:" + "nameType", json.toJSONString().contains("nameType"));
		Assert.assertTrue("JSON does not contain required data:" + "object", json.toJSONString().contains("object"));
	}
	
}