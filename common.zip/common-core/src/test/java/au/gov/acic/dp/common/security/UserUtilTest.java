package au.gov.acic.dp.common.security;

import java.util.Collections;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringRunner;

import au.gov.acic.dp.common.security.model.DataPipelineUser;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserUtilTest {

	@Autowired
	private UserUtil userUtil;

	@Test
	public void testGetCurrentUsername() throws Exception {
		final UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
				new DataPipelineUser.UserBuilder("username").build(), null, Collections.emptyList());
		SecurityContextHolder.getContext().setAuthentication(auth);
		final String username = userUtil.getCurrentUsername();
		Assert.assertTrue(StringUtils.equals(username, "username"));
	}


	@Test
	public void testGetCurrentUser() throws Exception {
		final UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
				new DataPipelineUser.UserBuilder("username").build(), null, Collections.emptyList());
		SecurityContextHolder.getContext().setAuthentication(auth);
		final DataPipelineUser user = userUtil.getCurrentUser();
		Assert.assertTrue(!Objects.isNull(user));
	}
}
