package au.gov.acic.dp.common.repository.hdfs;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.withSettings;

import java.io.InputStream;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PositionedReadable;
import org.apache.hadoop.fs.Seekable;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("hdfs")
public class HdfsRepositoryTest {

	@MockBean
	private FileSystem fileSystem;

	@MockBean
	private FSDataOutputStream mockFSOutputStream;

	@MockBean
	private FSDataInputStream mockFSInputStream;

	@Autowired
	private HdfsRepository repository;

	@Test
	public void testSave() throws Exception {
		final InputStream data = this.getClass().getResourceAsStream("/valid.csv");
		Mockito.when(fileSystem.create(Mockito.any(Path.class), Mockito.anyBoolean())).thenReturn(mockFSOutputStream);
		repository.save(getMockPath(), data);
	}

	@Test
	public void testFind() throws Exception {
		final InputStream in = mock(InputStream.class, withSettings().extraInterfaces(Seekable.class, PositionedReadable.class));
		doReturn(42).when(in).read(any(byte[].class), anyInt(), anyInt());
		mockFSInputStream = new FSDataInputStream(in);
		Mockito.when(fileSystem.open(Mockito.any(Path.class))).thenReturn(mockFSInputStream);
		repository.getFile(getMockPath());
	}

	private String getMockPath() {
		return "/data/dp/mock/2018-07-01/gdq38764gdjhae87_valid.csv";
	}
}
